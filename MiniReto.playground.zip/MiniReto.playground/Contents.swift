//: Playground - noun: a place where people can play



for num in 0...100{
    
    if num % 5 == 0 {
        print("Bingo: \(num)")
    }else if num % 2 == 0 {
        print("\(num) Par!")
    }else if num % 2 != 0{
        print("\(num) Impar!")
    }else if num == 30{
        print("Viva Swift!! \(num)")
    }
    switch num
    {
    case 30...40:
            print("\(num) Viva Swift!!")
        
    default:
        
        print("")
    }
}









